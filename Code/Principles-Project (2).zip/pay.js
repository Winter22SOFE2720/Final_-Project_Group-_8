const container = document.getElementById('container');
const button = googlePayClient.createButton({
  buttonColor: 'default',
  buttonType: 'buy',
  buttonLocale: 'en',
  onClick: () => {},
});

container.appendChild(button);

function buttonClick(){
  
}